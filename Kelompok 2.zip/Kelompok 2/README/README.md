FINHEALTH-APP 

FINHEALTH-APP adalah aplikasi web berbasis Flask untuk membantu analisis dan pengelolaan kesehatan finansial, dilengkapi fitur dashboard, histori, profil pengguna, serta modul prediksi keuangan menggunakan model ARIMA.

⸻

✨ Fitur Utama
	•	Autentikasi pengguna
	•	Dashboard ringkasan keuangan
	•	Riwayat transaksi
	•	Prediksi keuangan (ARIMA)
	•	Manajemen profil
	•	UI berbasis HTML templates & static assets

⸻

🧱 Tech Stack
	•	Backend: Python, Flask
	•	Frontend: HTML, CSS, JavaScript (Jinja Templates)
	•	Database: SQLite (default)
	•	Machine Learning: ARIMA (time series)
	•	Environment: Virtualenv

⸻

📂 Struktur Project

FINHEALTH-APP/
├── app/
│   ├── auth/
│   ├── dashboard/
│   ├── history/
│   ├── landing/
│   ├── prediction/
│   │   ├── arima_model.py
│   │   └── routes.py
│   ├── profile/
│   ├── static/
│   ├── templates/
│   ├── models.py
│   └── config.py
├── instance/
├── logs/
├── run.py
├── requirements.txt
├── finhealth_db.sql
└── setup_project.py


⸻

Cara Menjalankan Project

1️⃣ Clone Repository

git clone https://github.com/nauvalsyhfr/Finhealth-app
cd FINHEALTH-APP


⸻

2️⃣ Setup Virtual Environment

Disarankan Python 3.11

python3.11 -m venv venv311
source venv311/bin/activate   # macOS / Linux
# venv311\\Scripts\\activate    # Windows


⸻

3️⃣ Install Dependencies

pip install --upgrade pip
pip install -r requirements.txt


⸻

4️⃣ Konfigurasi Environment Variables

Buat file .env di root project:

FLASK_ENV=development
FLASK_APP=run.py
SECRET_KEY=your_secret_key
DATABASE_URL=sqlite:///finhealth.db


⸻

5️⃣ Setup Database

Jika menggunakan file SQL:

sqlite3 finhealth.db < finhealth_db.sql

Atau jalankan script setup:

python setup_project.py


⸻

6️⃣ Jalankan Aplikasi

python run.py

Akses aplikasi di browser:

http://127.0.0.1:5000


⸻

Modul Prediksi

Fitur prediksi keuangan menggunakan ARIMA time series model yang diimplementasikan pada:

app/prediction/arima_model.py

Digunakan untuk menganalisis dan memprediksi tren data finansial pengguna.

⸻

📝 Catatan
	•	Minimal Python 3.10 (disarankan 3.11)
	•	Gunakan virtual environment untuk menghindari konflik dependency
	•	Folder logs/ akan terisi otomatis saat aplikasi berjalan
